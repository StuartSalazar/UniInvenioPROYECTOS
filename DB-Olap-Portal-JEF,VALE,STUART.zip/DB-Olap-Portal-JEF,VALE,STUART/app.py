from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, login_user, login_required, logout_user, current_user, UserMixin
import pyodbc  # Para la conexión a la base de datos
from db_connection import get_db_connection  # Importamos la función de conexión
app = Flask(__name__)
app.secret_key = 'mysecrexxxx'#remplaza con clave secreta

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# ------------------------------------------------
# Funciones de autenticación y roles
# ------------------------------------------------

def get_user(username, password):
    conn = get_db_connection()
    if conn is None:
        return None
    cursor = conn.cursor()
    query = "SELECT UsuarioID, Nombre FROM Usuarios WHERE Nombre = ? AND Contrasena = ?"
    try:
        cursor.execute(query, (username, password))
        user = cursor.fetchone()
        return user
    except pyodbc.Error as e:
        print(f"Error al ejecutar la consulta de usuario: {e}")
        return None
    finally:
        cursor.close()
        conn.close()

def get_user_roles(usuario_id):
    conn = get_db_connection()
    if conn is None:
        return []
    cursor = conn.cursor()
    query = """
        SELECT r.Nombre 
        FROM Roles r
        JOIN UsuarioRoles ur ON r.RolID = ur.RolID
        WHERE ur.UsuarioID = ?
    """
    try:
        cursor.execute(query, (usuario_id,))
        roles = cursor.fetchall()
        return [role.Nombre for role in roles]
    except pyodbc.Error as e:
        print(f"Error al ejecutar la consulta de roles: {e}")
        return []
    finally:
        cursor.close()
        conn.close()

# ------------------------------------------------
# Funciones específicas por rol
# ------------------------------------------------

def get_admin_reservas():
    conn = get_db_connection()
    if conn is None:
        return []
    cursor = conn.cursor()
    query = """
    SELECT a.Modelo, COUNT(r.ReservaID) AS TotalReservas, SUM(r.MontoTotal) AS IngresosTotales
    FROM factreservas r
    JOIN DimAutobuses a ON r.AutobusID = a.AutobusID
    GROUP BY a.Modelo
    ORDER BY IngresosTotales DESC;

    """
    try:
        cursor.execute(query)
        reservas = cursor.fetchall()
        return reservas
    except pyodbc.Error as e:
        print(f"Error al obtener reservas: {e}")
        return []
    finally:
        cursor.close()
        conn.close()

def get_manager_report():
    conn = get_db_connection()
    if conn is None:
        return []
    cursor = conn.cursor()
    query = """
    SELECT a.Modelo, COUNT(r.ReservaID) AS TotalReservas, SUM(r.Ingresos) AS IngresosTotales
    FROM fact_reservas r
    JOIN DimAutobuses a ON r.AutobusID = a.AutobusID
    GROUP BY a.Modelo
    ORDER BY IngresosTotales DESC;
    """
    try:
        cursor.execute(query)
        report = cursor.fetchall()
        return report
    except pyodbc.Error as e:
        print(f"Error al obtener el reporte: {e}")
        return []
    finally:
        cursor.close()
        conn.close()

def execute_custom_query(query):
    if not query.strip().lower().startswith('select'):
        raise ValueError("Solo se permiten consultas SELECT.")
    conn = get_db_connection()
    if conn is None:
        raise Exception("Error de conexión a la base de datos.")
    cursor = conn.cursor()
    try:
        cursor.execute(query)
        results = cursor.fetchall()
        columns = [column[0] for column in cursor.description]
        return results, columns
    except pyodbc.Error as e:
        print(f"Error al ejecutar la consulta personalizada: {e}")
        raise
    finally:
        cursor.close()
        conn.close()

def run_job(job_name):
    if job_name == 'actualizar_reservas':
        # Aquí se ejecutaría la lógica de actualizar reservas
        return True, 'Job "Actualizar Reservas" ejecutado exitosamente.'
    return False, 'Job no reconocido.'

# ------------------------------------------------
# Clase User para manejar usuarios en Flask-Login
# ------------------------------------------------

class User(UserMixin):
    def __init__(self, id, username, roles):
        self.id = id
        self.username = username
        self.roles = roles

@login_manager.user_loader
def load_user(user_id):
    roles = get_user_roles(user_id)
    if not roles:
        return None
    user = get_user_by_id(user_id)
    if user:
        return User(user_id, user.Nombre, roles)
    return None

def get_user_by_id(user_id):
    conn = get_db_connection()
    if conn is None:
        return None
    cursor = conn.cursor()
    query = "SELECT Nombre FROM Usuarios WHERE UsuarioID = ?"
    try:
        cursor.execute(query, (user_id,))
        return cursor.fetchone()
    except pyodbc.Error as e:
        print(f"Error al cargar usuario: {e}")
        return None
    finally:
        cursor.close()
        conn.close()

# ------------------------------------------------
# Rutas para manejo de sesión
# ------------------------------------------------

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user_data = get_user(username, password)
        if user_data:
            usuario_id, nombre = user_data
            roles = get_user_roles(usuario_id)
            if roles:
                user = User(usuario_id, nombre, roles)
                login_user(user)
                flash('Inicio de sesión exitoso!', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash('No se encontraron roles asignados al usuario.', 'danger')
        else:
            flash('Nombre de usuario o contraseña incorrectos.', 'danger')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Has cerrado sesión.', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    roles = current_user.roles
    if 'Administrador' in roles:
        return redirect(url_for('admin_dashboard'))
    elif 'Gerente' in roles:
        return redirect(url_for('manager_dashboard'))
    elif 'Analista de Datos' in roles:
        return redirect(url_for('analyst_dashboard'))
    elif 'Developer' in roles:
        return redirect(url_for('dev_dashboard'))
    elif 'QA' in roles:
        return redirect(url_for('qa_dashboard'))
    else:
        flash('Rol no autorizado.', 'danger')
        return redirect(url_for('login'))

# ------------------------------------------------
# Rutas específicas por rol
# ------------------------------------------------

@app.route('/admin/dashboard', methods=['GET', 'POST'])
@login_required
def admin_dashboard():
    if 'Administrador' not in current_user.roles:
        flash('No tienes permisos para acceder a esta sección.', 'danger')
        return redirect(url_for('dashboard'))
    reservas = get_admin_reservas()
    return render_template('admin_dashboard.html', username=current_user.username, reservas=reservas)

@app.route('/manager/dashboard', methods=['GET', 'POST'])
@login_required
def manager_dashboard():
    if 'Gerente' not in current_user.roles:
        flash('No tienes permisos para acceder a esta sección.', 'danger')
        return redirect(url_for('dashboard'))
    report = get_manager_report()
    return render_template('manager_dashboard.html', username=current_user.username, report=report)

@app.route('/analyst/dashboard', methods=['GET', 'POST'])
@login_required
def analyst_dashboard():
    if 'Analista de Datos' not in current_user.roles:
        flash('No tienes permisos para acceder a esta sección.', 'danger')
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        query = request.form.get('custom_query')
        if query:
            results, columns = execute_custom_query(query)
            return render_template('analyst_dashboard.html', username=current_user.username, results=results, columns=columns)
    return render_template('analyst_dashboard.html', username=current_user.username)

@app.route('/dev/dashboard', methods=['GET', 'POST'])
@login_required
def dev_dashboard():
    if 'Developer' not in current_user.roles:
        flash('No tienes permisos para acceder a esta sección.', 'danger')
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        query = request.form.get('custom_query')
        if query:
            results, columns = execute_custom_query(query)
            return render_template('dev_dashboard.html', username=current_user.username, results=results, columns=columns)
    return render_template('dev_dashboard.html', username=current_user.username)

@app.route('/qa/dashboard', methods=['GET', 'POST'])
@login_required
def qa_dashboard():
    if 'QA' not in current_user.roles:
        flash('No tienes permisos para acceder a esta sección.', 'danger')
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        job_name = request.form.get('job_name')
        if job_name:
            success, message = run_job(job_name)
            flash(message, 'success' if success else 'danger')
    return render_template('qa_dashboard.html', username=current_user.username)


app.run(debug=True)

import pyodbc

def get_db_connection():
    """
    Establece una conexión a la base de datos SQL Server.
    Retorna el objeto de conexión si tiene éxito, de lo contrario None.
    """
    conn_str = (
        r'DRIVER={ODBC Driver 17 for SQL Server};'
        r'SERVER=Sxxxxx;'  # Reemplaza con tu servidor
        r'DATABASE=Exxxxx;'  # Reemplaza con tu base de datos
        r'Trusted_Connection=yes;'  # O utiliza User ID y Password si es necesario
    )
    try:
        conn = pyodbc.connect(conn_str)
        print("Conexión a la base de datos exitosa.")
        return conn
    except pyodbc.Error as e:
        print(f"Error al conectar a la base de datos: {e}")
        return None
